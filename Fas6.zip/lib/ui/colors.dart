import 'dart:ui';

const Color green = Color(0xff158442);
const Color lightGrey = Color(0xff5f6367);
const Color shim = Color(0x7f000000);